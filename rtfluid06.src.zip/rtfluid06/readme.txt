Real-Time Particle-Based Fluid Simulation
  The demo binary shows it can handle 2000 particles at about 30 fps on Pentium 4 2.8GHz.
  And you can interact with the fluids by dragging.

System Requirements
  - Microsoft Windows 2000 or later
  - Intel x86 Compatible Processor
  - Visual Studio .NET 2003 or later to build
  - OpenGL ARB Fragment Program and Vertex Program
    Water is not shaded properly on some ATI RADEON series 

Acknowledgement
  The cubemap texture included in the demo is credited to Peter Murphy. Thank you, Paul Bourke! 
