const char* fp_str_kernel=
"";
