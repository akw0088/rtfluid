const char* fp_str_sum_density=
"";
