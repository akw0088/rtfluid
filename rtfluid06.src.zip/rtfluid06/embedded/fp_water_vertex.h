const char* fp_str_water_vertex=
"";
